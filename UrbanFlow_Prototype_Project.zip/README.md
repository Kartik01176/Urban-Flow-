# Cooperative Navigation Prototype

This is a basic Android app structure representing the **Cooperative Navigation** prototype.

## 📂 Project Structure

- `MainActivity.kt` → Main entry point for the app (logic and UI binding)
- `AndroidManifest.xml` → App permissions, launcher activity configuration
- `activity_main.xml` → UI layout of the main screen
- `strings.xml` → Contains app name and static strings
- `build.gradle` → Basic Gradle structure

## ⚡ Features
- GNSS + IMU data concept ready
- Location permission setup
- Launcher activity working
- Lightweight UI for testing

## 📌 How to use
1. Extract this ZIP inside Android Studio `AndroidStudioProjects`.
2. Open the project in Android Studio.
3. Build and Run.

🛡️ This is a minimal structure to be extended for peer-to-peer cooperative navigation system.
